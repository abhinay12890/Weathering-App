import json
from flask import Flask, render_template, request, jsonify   
import requests
app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")        

@app.route("/submitJSON", methods=["POST"])
def processJSON(): 
    jsonStr = request.get_json()
    jsonObj = json.loads(jsonStr)
    
    global location,temp,feels_like,weather,description
    city=jsonObj['city']
    api_id="a96ef0d2a8ecba295fb56ef5352fb46b"
    api_url=f"https://api.openweathermap.org/data/2.5/weather?q={city}&APPID={api_id}&units=metric"
    data=requests.get(api_url).json()
    temp="{0:.2f}".format(data['main']['temp'])
    feels_like="{0:.2f}".format(data['main']['feels_like'])
    weather=data['weather'][0]['main']
    location=data['name']
    description=data['weather'][0]['description']

    return render_template("results.html",location=location,temp=temp,feels_like=feels_like,weather=weather,description=description)
    
    
if __name__=='__main__':
	app.run()
